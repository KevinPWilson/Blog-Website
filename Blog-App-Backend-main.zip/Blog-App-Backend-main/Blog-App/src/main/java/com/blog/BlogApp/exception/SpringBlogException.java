package com.blog.BlogApp.exception;

public class SpringBlogException extends Throwable {
    public SpringBlogException(String message) {
        super(message);
    }
}
